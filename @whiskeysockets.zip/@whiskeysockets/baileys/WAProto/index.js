// index.js
// Saud's Custom Baileys Fork Starter

function injectChannel(message) {
  // 👇 Yahan apna WhatsApp channel ID dalna hai
  message.annotations = [{
    newsletter: {
      newsletterJid: "0029Va8XyAbCdEfGhIjKlMnOp@newsletter", // apna channel ID
      newsletterName: "Saud Bot Channel" // apna channel ka naam
    }
  }];
  return message;
}

function startBot() {
  const msg = { text: "Hello from Saud's fork!" };

  // Inject apna channel info
  const cleanMsg = injectChannel(msg);

  // Console output for testing
  console.log("Outgoing message:", cleanMsg);
}

// Run bot
startBot();