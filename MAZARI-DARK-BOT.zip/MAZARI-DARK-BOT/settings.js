const settings = {
  packname: 'MAZARI-DARK-BOT',
  author: '‎',
  botName: "MAZARI-DARK-BOT",
  botOwner: 'Saud-mazari', // Your name
  ownerNumber: '+923293257500', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/rabeetmuhammad1-ai/thunder-beta-304.zip",
};

module.exports = settings;
